int main(void) {
    const char *text = "string contains // and /* markers";
    char quote = '\'';
    /* This block comment
       continues on another line. */
    int value = 7;
    value += 2;
    return value;
}