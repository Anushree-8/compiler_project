#include <stdio.h>

unsigned int transform(unsigned int value) {
    value = (value << 2) | (value >> 3);
    value ^= (value & 255U) + 17U;
    if (value >= 100U && value != 255U) value -= 7U;
    return value;
}
