# Review 2 evaluation pack

This pack provides small correctness inputs and repeatable larger workloads for comparing token output, chunk-boundary handling, Unicode audit behavior, and one-, two-, four-, and eight-worker timings. It does not modify `plex.c` or replace `sample.c`.

## Build and run correctness examples

Open PowerShell in the project folder (the folder containing `plex.exe`) and run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
& .\build.bat
& .\plex.exe .\review2_evaluation\samples\baseline.c --threads 1 --tokens
& .\plex.exe .\review2_evaluation\samples\baseline.c --threads 4 --tokens
& .\plex.exe .\review2_evaluation\samples\boundary_state.c --threads 4 --tokens
& .\plex.exe .\review2_evaluation\samples\unicode_audit.c --threads 4 --tokens --audit
& .\plex.exe .\review2_evaluation\samples\operator_mix.c --threads 4 --tokens
```

The Unicode sample intentionally includes selected mixed-script identifiers, a non-ASCII identifier, and invisible formatting characters. Its warnings are review prompts, not conclusions about intent.

## Compare one worker with four

```powershell
& .\review2_evaluation\compare_workers.ps1 -InputFile .\review2_evaluation\samples\boundary_state.c -Workers 4
& .\review2_evaluation\compare_workers.ps1 -InputFile .\review2_evaluation\samples\unicode_audit.c -Workers 4
& .\review2_evaluation\compare_workers.ps1 -InputFile .\review2_evaluation\samples\operator_mix.c -Workers 4
```

`PASS` means all printed token rows match, including location, type, and displayed lexeme. Lexemes longer than 48 characters are abbreviated in the command-line display, so this does not prove full-text equality for those tokens.

## Generate larger workload families

```powershell
& .\review2_evaluation\generate_large_samples.ps1
```

The generator creates token-dense and comment/string-heavy C sources at approximately 1 MB, 5 MB, and 10 MB, plus operator-heavy sources at 5 MB and 10 MB. `operator_mix.c` is the hand-written small correctness example. Generated files contain repeated valid C-like routines and are designed to stress lexical scanning, not to represent a production application.

## Run the expanded benchmark

After generation, run the full default matrix:

```powershell
& .\review2_evaluation\benchmark.ps1 -RepeatCount 7
```

This measures eight larger inputs at 1, 2, 4, and 8 workers, with one warm-up and seven timed trials for each setting. It writes raw observations and medians/ranges to `review2_evaluation\results\benchmark_expanded.csv` and `benchmark_expanded_medians.csv`. Every run records file bytes, token count, lexical errors, chunks, and elapsed milliseconds. The report includes the four 1 MB/5 MB token-dense and comment/string workloads from the supplied seven-trial screenshot, plus a separate locally captured exploratory run for the new 10 MB and operator-heavy cases. The new run has three trials per setting; its raw data is saved separately as `benchmark_expanded_3trial.csv` and `benchmark_expanded_3trial_medians.csv`.

For a shorter initial run, test only 5 MB and 10 MB files:

```powershell
& .\review2_evaluation\benchmark.ps1 -RepeatCount 5 -InputFiles @('.\review2_evaluation\samples\large_token_dense_5mb.c','.\review2_evaluation\samples\large_token_dense_10mb.c','.\review2_evaluation\samples\large_comment_string_5mb.c','.\review2_evaluation\samples\large_comment_string_10mb.c','.\review2_evaluation\samples\large_operator_heavy_5mb.c','.\review2_evaluation\samples\large_operator_heavy_10mb.c')
```

Timings include process startup and the full lexer pipeline. Compare configurations on the same machine/build and report medians plus ranges. If ranges are wide, repeat with the machine otherwise idle. Record CPU, RAM, OS build, compiler version, and flags. More workers can be slower when scheduling, allocation, or ordered merging outweigh scanning work.

## What the current captured results support

On the four captured inputs (about 1 MB and 5 MB, two content mixes), token counts and zero lexical errors stayed constant across 1, 2, 4, and 8 workers. The 5 MB token-dense case showed a 1.78x eight-worker median speedup; smaller or comment/string-heavy workloads showed weaker or inconsistent gains. This makes the implementation acceptable as a functional academic prototype with conditional speedup evidence. It does not yet establish a general speedup or production-grade lexer correctness. The new large and operator-heavy runs can strengthen or challenge that conclusion.
