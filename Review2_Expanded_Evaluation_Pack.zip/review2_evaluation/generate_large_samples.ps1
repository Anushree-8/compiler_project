param()

$ErrorActionPreference = 'Stop'
$samples = Join-Path $PSScriptRoot 'samples'
New-Item -ItemType Directory -Force -Path $samples | Out-Null
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Workload([string]$Name, [int]$TargetBytes, [string]$Kind) {
    $builder = New-Object System.Text.StringBuilder
    [void]$builder.AppendLine('#include <stdio.h>')
    [void]$builder.AppendLine('')
    $index = 0
    while ($builder.Length -lt $TargetBytes) {
        if ($Kind -eq 'comments') {
            [void]$builder.Append("/* block note for routine $index`n   comment markers // and quotes `" stay inside this comment`n   operators + - * / and braces { } remain comment text */`n")
            [void]$builder.Append("int routine_$index(int value) {`n")
            [void]$builder.Append("    const char *label_$index = `"routine $index; // string text /* still string */`";`n")
            [void]$builder.Append("    char mark_$index = 'A';`n")
            [void]$builder.Append("    return value + $index;`n}")
        } elseif ($Kind -eq 'operators') {
            [void]$builder.Append("unsigned long routine_$index(unsigned long value) {`n")
            [void]$builder.Append("    value = (value << 2) | (value >> 3);`n")
            [void]$builder.Append("    value ^= (value & 255U) + ($index * 17U);`n")
            [void]$builder.Append("    if (value >= 100U && value != 255U) value -= 7U;`n")
            [void]$builder.Append("    return value;`n}")
        } else {
            [void]$builder.Append("int routine_$index(int value) {`n")
            [void]$builder.Append("    int result = value + $index;`n")
            [void]$builder.Append("    result = (result * 3) ^ ($index & 255);`n")
            [void]$builder.Append("    if (result >= 100) result -= 7;`n")
            [void]$builder.Append("    return result;`n}")
        }
        [void]$builder.AppendLine('')
        $index++
    }
    $path = Join-Path $samples $Name
    [System.IO.File]::WriteAllText($path, $builder.ToString(), $utf8NoBom)
    $bytes = (Get-Item -LiteralPath $path).Length
    Write-Output ("Created {0}: {1:N0} bytes, {2:N0} generated routines" -f $path, $bytes, $index)
}

foreach ($size in @(1, 5, 10)) {
    $bytes = $size * 1MB
    Write-Workload "large_token_dense_${size}mb.c" $bytes 'tokens'
    Write-Workload "large_comment_string_${size}mb.c" $bytes 'comments'
}
foreach ($size in @(5, 10)) {
    $bytes = $size * 1MB
    Write-Workload "large_operator_heavy_${size}mb.c" $bytes 'operators'
}
